package com.orbispro.android.data

import com.orbispro.android.model.Ps2Game
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlinx.coroutines.test.runTest

class GameProviderTest {
    @Test fun emptyProviderReturnsNoGames() = runTest {
        assertEquals(emptyList(), FakeGameProvider("PS2").refresh())
    }

    @Test fun parsesPs2SerialWhenFilenameContainsIt() {
        assertEquals("SLUS-21216", GameFileMetadata.serialFromName("God of War [SLUS-21216].iso"))
        assertNull(GameFileMetadata.serialFromName("unknown-game.iso"))
    }

    @Test fun fakeProviderKeepsPlatformData() = runTest {
        val games = FakeGameProvider("PS2", listOf(Ps2Game("Demo", "SLUS-00001"))).refresh()
        assertEquals("PS2", games.single().platform)
    }
}
