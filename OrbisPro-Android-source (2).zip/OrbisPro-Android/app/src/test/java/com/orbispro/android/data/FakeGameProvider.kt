package com.orbispro.android.data

import com.orbispro.android.model.Game

class FakeGameProvider(override val platform: String, private val initial: List<Game> = emptyList()) : IGameProvider {
    override suspend fun refresh(): List<Game> = initial
}
