package com.orbispro.android.data

import com.orbispro.android.model.Game

/** Wii cover resolution is deliberately independent from PS2 serial URLs. */
object WiiCoverService {
    fun sources(game: Game): List<String> = emptyList()
}
