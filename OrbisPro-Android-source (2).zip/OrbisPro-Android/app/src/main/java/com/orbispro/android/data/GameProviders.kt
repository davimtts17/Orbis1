package com.orbispro.android.data

import android.content.Context
import com.orbispro.android.model.Game
import com.orbispro.android.model.Ps2Game
import com.orbispro.android.model.WiiGame
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

interface IGameProvider { val platform: String; suspend fun refresh(): List<Game> }

abstract class DocumentTreeGameProvider(protected val context: Context) : IGameProvider {
    protected abstract val supportedExtensions: Set<String>
    protected abstract fun makeGame(name: String, serial: String?, uri: String, format: String, size: Long?): Game

    override suspend fun refresh(): List<Game> = withContext(Dispatchers.IO) {
        val rootUri = LibraryUriStore(context).get(platform) ?: return@withContext emptyList()
        val root = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, android.net.Uri.parse(rootUri)) ?: return@withContext emptyList()
        runCatching {
            val result = mutableListOf<Game>()
            scan(root, result)
            result.distinctBy { "${it.platform}|${it.name.lowercase()}" }
        }.getOrDefault(emptyList())
    }

    private fun scan(directory: androidx.documentfile.provider.DocumentFile, result: MutableList<Game>) {
        directory.listFiles().forEach { file ->
            if (file.isDirectory) scan(file, result)
            else {
                val extension = file.name?.substringAfterLast('.', "")?.lowercase() ?: return@forEach
                if (extension in supportedExtensions) {
                    val name = GameFileMetadata.displayName(file.name!!)
                    val serial = GameFileMetadata.serialFromName(file.name!!)
                    result += makeGame(name, serial, file.uri.toString(), extension, file.length().takeIf { it >= 0 })
                }
            }
        }
    }
}

class Ps2GameProvider(context: Context) : DocumentTreeGameProvider(context) {
    override val platform = "PS2"
    override val supportedExtensions = setOf("iso", "chd", "cso", "bin", "cue", "gz", "dump")
    override fun makeGame(name: String, serial: String?, uri: String, format: String, size: Long?) = Ps2Game(name, serial, contentUri = uri, format = format, sizeBytes = size)
}

class WiiGameProvider(context: Context) : DocumentTreeGameProvider(context) {
    override val platform = "Wii"
    override val supportedExtensions = setOf("iso", "wbfs", "rvz", "wia", "gcz", "ciso")
    override fun makeGame(name: String, serial: String?, uri: String, format: String, size: Long?) = WiiGame(name, serial, contentUri = uri, format = format, sizeBytes = size)
}
