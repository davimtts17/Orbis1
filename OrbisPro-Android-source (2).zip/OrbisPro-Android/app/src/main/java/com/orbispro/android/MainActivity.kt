package com.orbispro.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import com.orbispro.android.ui.OrbisApp
import com.orbispro.android.ui.OrbisTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OrbisTheme(darkTheme = true) { OrbisApp() } }
    }
}
