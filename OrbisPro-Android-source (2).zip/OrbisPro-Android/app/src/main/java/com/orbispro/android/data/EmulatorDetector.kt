package com.orbispro.android.data

import android.content.Context

/** Only reports installed package candidates. It never scans private Android data directories. */
class EmulatorDetector(private val context: Context) {
    data class EmulatorStatus(val installed: Boolean, val packageName: String?)

    fun netherSx2(): EmulatorStatus = find(listOf("xyz.aethersx2.android", "com.aethersx2.android", "xyz.aethersx2.android.alpha"))
    fun dolphin(): EmulatorStatus = find(listOf("org.dolphinemu.dolphinemu", "org.dolphinemu.dolphinemu.dev"))

    private fun find(candidates: List<String>): EmulatorStatus {
        val packageManager = context.packageManager
        val match = candidates.firstOrNull { runCatching { packageManager.getApplicationInfo(it, 0) }.isSuccess }
        return EmulatorStatus(match != null, match)
    }
}
