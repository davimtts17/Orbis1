package com.orbispro.android.model

open class Game(
    open val name: String,
    open val serial: String?,
    open val platform: String,
    open val availability: String = "",
    open val contentUri: String? = null,
    open val format: String? = null,
    open val sizeBytes: Long? = null
)

data class Ps2Game(
    override val name: String,
    override val serial: String?,
    override val availability: String = "Detected",
    override val contentUri: String? = null,
    override val format: String? = null,
    override val sizeBytes: Long? = null,
    val isDummy: Boolean = false
) : Game(name, serial, "PS2", availability, contentUri, format, sizeBytes)

data class WiiGame(
    override val name: String,
    override val serial: String?,
    override val availability: String = "Detected",
    override val contentUri: String? = null,
    override val format: String? = null,
    override val sizeBytes: Long? = null
) : Game(name, serial, "Wii", availability, contentUri, format, sizeBytes)
