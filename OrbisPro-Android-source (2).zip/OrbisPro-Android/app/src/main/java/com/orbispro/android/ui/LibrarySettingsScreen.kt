package com.orbispro.android.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.orbispro.android.data.EmulatorDetector
import com.orbispro.android.data.LibraryUriStore

@Composable
fun LibrarySettingsScreen(onBack: () -> Unit, onRefresh: () -> Unit) {
    val context = LocalContext.current
    val store = remember { LibraryUriStore(context) }
    var selectedPlatform by remember { mutableStateOf("PS2") }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            runCatching { context.contentResolver.takePersistableUriPermission(uri, flags) }
            store.set(selectedPlatform, uri.toString())
            onRefresh()
        }
    }
    val detector = remember { EmulatorDetector(context) }
    val status = if (selectedPlatform == "PS2") detector.netherSx2() else detector.dolphin()
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Bibliotecas", color = Color.White, fontSize = 32.sp); Text("Voltar", color = Color.White, modifier = Modifier.clickable { onBack() }) }
        Text("${selectedPlatform} / ${if (selectedPlatform == "PS2") "NetherSX2" else "Dolphin"}", color = Color.White, fontSize = 22.sp)
        Text(if (status.installed) "Emulador detectado: ${status.packageName}" else "Emulador não detectado automaticamente", color = Color.White.copy(.75f), fontSize = 15.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilterChip(selected = selectedPlatform == "PS2", onClick = { selectedPlatform = "PS2" }, label = { Text("PS2") })
            FilterChip(selected = selectedPlatform == "Wii", onClick = { selectedPlatform = "Wii" }, label = { Text("Wii") })
        }
        Text("Pasta autorizada: ${store.get(selectedPlatform) ?: "nenhuma"}", color = Color.White.copy(.68f), fontSize = 14.sp)
        Button(onClick = { launcher.launch(null) }) { Text("Selecionar pasta de jogos") }
        Text("O Android não permite ao app varrer /Android/data ou /Android/obb diretamente. Esta seleção usa o Storage Access Framework e a permissão persistente do usuário.", color = Color.White.copy(.58f), fontSize = 14.sp)
    }
}
