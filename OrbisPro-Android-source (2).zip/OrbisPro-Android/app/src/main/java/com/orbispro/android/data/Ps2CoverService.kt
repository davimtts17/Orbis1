package com.orbispro.android.data

import com.orbispro.android.model.Game

object Ps2CoverService {
    private const val threeD = "https://raw.githubusercontent.com/xlenore/ps2-covers/main/covers/3d/%s.png"
    private const val default = "https://raw.githubusercontent.com/xlenore/ps2-covers/main/covers/default/%s.jpg"

    fun sources(serial: String): List<String> = listOf(
        threeD.format(serial),
        default.format(serial)
    )

    fun sources(game: Game): List<String> = if (game.platform == "PS2" && !game.serial.isNullOrBlank()) sources(game.serial!!) else emptyList()
}
