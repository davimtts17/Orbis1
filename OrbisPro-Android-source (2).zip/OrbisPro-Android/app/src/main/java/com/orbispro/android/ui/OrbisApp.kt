package com.orbispro.android.ui

import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.orbispro.android.data.AppConfig
import com.orbispro.android.data.Ps2GameProvider
import com.orbispro.android.data.Ps2GameRepository
import com.orbispro.android.data.WiiGameProvider
import com.orbispro.android.model.Game
import kotlinx.coroutines.launch

enum class OrbisScreen { Home, Library, Settings }

@Composable
fun OrbisApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val ps2Provider = remember { Ps2GameProvider(context) }
    val wiiProvider = remember { WiiGameProvider(context) }
    var ps2Games by remember { mutableStateOf<List<Game>>(emptyList()) }
    var wiiGames by remember { mutableStateOf<List<Game>>(emptyList()) }
    var platform by remember { mutableStateOf("PS2") }
    var screen by remember { mutableStateOf(OrbisScreen.Home) }

    fun refresh() { scope.launch { ps2Games = ps2Provider.refresh(); wiiGames = wiiProvider.refresh() } }
    LaunchedEffect(Unit) { refresh() }
    val visibleGames = if (platform == "PS2") ps2Games else wiiGames
    val homeGames = ps2Games + wiiGames
    val developmentGames = if (AppConfig.USE_DUMMY_GAMES) Ps2GameRepository().games() else emptyList()

    OrbisBackground {
        when (screen) {
            OrbisScreen.Home -> HomeScreen(homeGames + developmentGames, onOpenLibrary = { screen = OrbisScreen.Library }, onOpenSettings = { screen = OrbisScreen.Settings })
            OrbisScreen.Library -> GameLibraryScreen(visibleGames + if (platform == "PS2") developmentGames else emptyList(), platform, { platform = it }, ::refresh, { screen = OrbisScreen.Settings }) { screen = OrbisScreen.Home }
            OrbisScreen.Settings -> LibrarySettingsScreen(onBack = { screen = OrbisScreen.Home }, onRefresh = ::refresh)
        }
    }
}
