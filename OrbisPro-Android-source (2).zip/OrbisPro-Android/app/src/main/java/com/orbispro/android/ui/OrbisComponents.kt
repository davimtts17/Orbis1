package com.orbispro.android.ui

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.ImageLoader
import coil.disk.DiskCache
import coil.compose.AsyncImage
import com.orbispro.android.R
import com.orbispro.android.data.Ps2CoverService
import com.orbispro.android.data.WiiCoverService
import com.orbispro.android.model.Game
import java.io.File

@Composable
fun OrbisBackground(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF07192C), Color(0xFF020812), Color(0xFF062240))))) {
        Canvas(Modifier.fillMaxSize()) {
            val dotColor = Color(0x55369EFF)
            for (x in 30..width.toInt() step 180) for (y in 30..height.toInt() step 180) drawCircle(dotColor, 2.5f, Offset(x.toFloat(), y.toFloat()))
            drawOval(Color(0x33228ED8), Offset(-180f, size.height * .15f), Size(size.width * .85f, size.height * .42f), style = androidx.compose.ui.graphics.drawscope.Stroke(4f))
            drawOval(Color(0x22228ED8), Offset(size.width * .32f, size.height * .48f), Size(size.width * .72f, size.height * .6f), style = androidx.compose.ui.graphics.drawscope.Stroke(4f))
        }
        content()
    }
}

@Composable
fun rememberOrbisImageLoader(context: Context): ImageLoader = remember(context) {
    ImageLoader.Builder(context).diskCache {
        DiskCache.Builder().directory(File(context.cacheDir, "ps2-covers")).maxSizeBytes(50L * 1024 * 1024).build()
    }.build()
}

@Composable
fun CoverImage(game: Game, modifier: Modifier = Modifier) {
    var stage by remember(game.serial) { mutableIntStateOf(0) }
    val sources = remember(game.platform, game.serial) { if (game.platform == "PS2") Ps2CoverService.sources(game) else WiiCoverService.sources(game) }
    val context = LocalContext.current
    val model: Any = sources.getOrNull(stage) ?: R.drawable.orbis_library_placeholder
    AsyncImage(model = model, imageLoader = rememberOrbisImageLoader(context), contentDescription = "Capa de ${game.name}", contentScale = ContentScale.Fit, modifier = modifier, onError = { if (stage < sources.lastIndex) stage++ })
}

@Composable
fun CommandBar(modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("◯  Close", fontSize = 16.sp, color = Color.White.copy(alpha = .78f))
        Text("×  Start", fontSize = 16.sp, color = Color.White.copy(alpha = .78f))
        Text("△  Other Options", fontSize = 16.sp, color = Color.White.copy(alpha = .78f))
    }
}

@Composable
fun ScreenTitle(text: String) { Text(text, fontSize = 34.sp, fontWeight = FontWeight.Light, color = Color.White, modifier = Modifier.padding(start = 24.dp, top = 18.dp, bottom = 12.dp)) }
