package com.orbispro.android.data

/** Production is always real-libraries-only. Enable only in a local development build when needed. */
object AppConfig {
    const val USE_DUMMY_GAMES = false
}
