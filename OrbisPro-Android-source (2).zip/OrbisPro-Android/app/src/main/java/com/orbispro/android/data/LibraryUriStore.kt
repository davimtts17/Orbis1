package com.orbispro.android.data

import android.content.Context

class LibraryUriStore(context: Context) {
    private val preferences = context.getSharedPreferences("orbis-library", Context.MODE_PRIVATE)
    fun get(platform: String): String? = preferences.getString(platform, null)
    fun set(platform: String, uri: String) { preferences.edit().putString(platform, uri).apply() }
    fun clear(platform: String) { preferences.edit().remove(platform).apply() }
}
