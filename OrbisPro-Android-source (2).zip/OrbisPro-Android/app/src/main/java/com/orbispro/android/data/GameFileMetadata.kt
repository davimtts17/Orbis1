package com.orbispro.android.data

object GameFileMetadata {
    private val serialPattern = Regex("(?i)([A-Z]{4,5}-\\d{4,6}|[A-Z0-9]{6})")
    fun displayName(fileName: String): String = fileName.substringBeforeLast('.', fileName)
    fun serialFromName(fileName: String): String? = serialPattern.find(fileName)?.value?.uppercase()
}
