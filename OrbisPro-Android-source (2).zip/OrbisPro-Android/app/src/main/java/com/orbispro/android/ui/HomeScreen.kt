package com.orbispro.android.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.orbispro.android.R
import com.orbispro.android.model.Game

private data class HomeItem(val title: String, val icon: Int? = null, val game: Game? = null)

@Composable
fun HomeScreen(games: List<Game>, onOpenLibrary: () -> Unit, onOpenSettings: () -> Unit) {
    val fixed = listOf(
        HomeItem("Twitter", R.drawable.orbis_twitter), HomeItem("Browser", R.drawable.orbis_browser), HomeItem("Gallery", R.drawable.orbis_gallery),
        HomeItem("Library", R.drawable.orbis_library), HomeItem("Explorer", R.drawable.orbis_explorer), HomeItem("Settings", R.drawable.orbis_settings), HomeItem("Orbis Update", R.drawable.orbis_update)
    )
    val items = fixed + games.map { HomeItem(it.name, game = it) }
    var selected by remember { mutableIntStateOf(0) }
    var functionsOpen by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val requester = remember { FocusRequester() }

    Column(Modifier.fillMaxSize().focusRequester(requester).focusable().onPreviewKeyEvent { event ->
        if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
        when (event.key) {
            Key.DirectionRight -> { selected = (selected + 1).coerceAtMost(items.lastIndex); true }
            Key.DirectionLeft -> { selected = (selected - 1).coerceAtLeast(0); true }
            Key.F2 -> { functionsOpen = !functionsOpen; true }
            else -> false
        }
    }) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 20.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("OrbisPro Beta", color = Color.White, fontSize = 18.sp)
            Text("SvenGDK", color = Color.White, fontSize = 18.sp)
            Text("WirelessLAN - 100%     00:00", color = Color.White.copy(alpha = .78f), fontSize = 16.sp)
        }
        Spacer(Modifier.weight(1f))
        LazyRow(state = listState, modifier = Modifier.fillMaxWidth().height(270.dp), contentPadding = PaddingValues(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            itemsIndexed(items) { index, item ->
                val isSelected = selected == index
                LaunchedEffect(selected) { if (isSelected) listState.animateScrollToItem(index) }
                Column(Modifier.width(if (isSelected) 260.dp else 160.dp).fillMaxHeight().clickable { selected = index; if (item.title == "Library") onOpenLibrary(); if (item.title == "Settings") onOpenSettings() }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.fillMaxWidth().height(if (isSelected) 220.dp else 160.dp).border(if (isSelected) 2.dp else 0.dp, Color.White)) {
                        if (item.game != null) CoverImage(item.game, Modifier.fillMaxSize().padding(4.dp))
                        else item.icon?.let { Image(painterResource(it), item.title, Modifier.fillMaxSize().padding(12.dp)) }
                    }
                    if (isSelected) { Text("Start", color = Color.White, fontSize = 16.sp); Text(item.title, color = Color.White, fontSize = 28.sp, textAlign = TextAlign.Center) }
                }
            }
        }
        Spacer(Modifier.weight(1f))
        if (functionsOpen) {
            Surface(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 6.dp), color = Color.Black.copy(alpha = .9f)) { Column(Modifier.padding(16.dp)) { Text("Add to Folder", color = Color.White, fontSize = 20.sp); Text("Delete", color = Color.White, fontSize = 20.sp); Text("Information", color = Color.White, fontSize = 20.sp) } }
        }
        CommandBar()
    }
    LaunchedEffect(Unit) { requester.requestFocus() }
}
