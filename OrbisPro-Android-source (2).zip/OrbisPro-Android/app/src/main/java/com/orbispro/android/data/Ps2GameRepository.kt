package com.orbispro.android.data

import com.orbispro.android.model.Ps2Game

interface GameRepository { fun games(): List<Ps2Game> }

class Ps2GameRepository : GameRepository {
    override fun games() = listOf(
        Ps2Game("God of War", "SLUS-21216"),
        Ps2Game("God of War II", "SLUS-21435"),
        Ps2Game("Shadow of the Colossus", "SCUS-97472"),
        Ps2Game("Resident Evil 4", "SLUS-21134"),
        Ps2Game("Gran Turismo 4", "SCUS-97328"),
        Ps2Game("Need for Speed Underground 2", "SLUS-21065"),
        Ps2Game("Devil May Cry 3", "SLUS-21271"),
        Ps2Game("Metal Gear Solid 3", "SLUS-21243"),
        Ps2Game("Final Fantasy X", "SLUS-20312"),
        Ps2Game("Kingdom Hearts II", "SLUS-21005")
    )
}
