package com.orbispro.android.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.orbispro.android.model.Game

@Composable
fun GameLibraryScreen(
    games: List<Game>,
    platform: String,
    onPlatformChange: (String) -> Unit,
    onRefresh: () -> Unit,
    onSettings: () -> Unit,
    onBack: () -> Unit
) {
    var selected by remember { mutableIntStateOf(0) }
    val requester = remember { FocusRequester() }
    val safeSelected = selected.coerceIn(0, (games.size - 1).coerceAtLeast(0))
    Row(Modifier.fillMaxSize().focusRequester(requester).focusable().onPreviewKeyEvent { event ->
        if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
        when (event.key) {
            Key.Escape, Key.Backspace -> { onBack(); true }
            Key.DirectionRight -> { selected = (safeSelected + 1).coerceAtMost((games.size - 1).coerceAtLeast(0)); true }
            Key.DirectionLeft -> { selected = (safeSelected - 1).coerceAtLeast(0); true }
            Key.F5 -> { onRefresh(); true }
            else -> false
        }
    }) {
        Column(Modifier.width(108.dp).fillMaxHeight().padding(top = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("◉", color = Color.White, fontSize = 42.sp)
            Spacer(Modifier.height(24.dp)); Text("▣", color = Color.White.copy(.55f), fontSize = 38.sp)
            Spacer(Modifier.height(18.dp)); Text("—", color = Color.White, fontSize = 30.sp)
            Spacer(Modifier.height(18.dp))
            Text("PS2", color = if (platform == "PS2") Color.White else Color.White.copy(.45f), fontSize = 15.sp, modifier = Modifier.clickable { onPlatformChange("PS2") })
            Spacer(Modifier.height(18.dp))
            Text("Wii", color = if (platform == "Wii") Color.White else Color.White.copy(.45f), fontSize = 15.sp, modifier = Modifier.clickable { onPlatformChange("Wii") })
            Spacer(Modifier.weight(1f))
            Text("⚙", color = Color.White.copy(.75f), fontSize = 25.sp, modifier = Modifier.padding(bottom = 28.dp).clickable { onSettings() })
        }
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                ScreenTitle("Library")
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(platform, color = Color.White.copy(.75f), fontSize = 18.sp)
                    Text("Atualizar", color = Color.White, fontSize = 15.sp, modifier = Modifier.clickable { onRefresh() }.padding(end = 24.dp))
                }
            }
            if (games.isEmpty()) {
                Column(Modifier.fillMaxSize().weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("Nenhum jogo ${platform} encontrado", color = Color.White, fontSize = 24.sp)
                    Text("Configure uma pasta em Configurações > Bibliotecas", color = Color.White.copy(.65f), fontSize = 15.sp, modifier = Modifier.padding(top = 10.dp))
                }
            } else {
                LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 300.dp), modifier = Modifier.weight(1f).padding(horizontal = 12.dp), contentPadding = PaddingValues(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(games) { index, game ->
                        val isSelected = index == safeSelected
                        Row(Modifier.height(150.dp).fillMaxWidth().background(Color.Black.copy(.5f)).border(if (isSelected) 2.dp else 0.dp, Color.White).clickable { selected = index }, verticalAlignment = Alignment.CenterVertically) {
                            CoverImage(game, Modifier.width(145.dp).fillMaxHeight().padding(3.dp))
                            Column(Modifier.padding(12.dp)) { Text(game.name, color = Color.White, fontSize = 21.sp, maxLines = 3, overflow = TextOverflow.Ellipsis); Spacer(Modifier.weight(1f)); Text("${game.serial ?: "ID pendente"} · ${game.format ?: "formato"}", color = Color.White.copy(.62f), fontSize = 12.sp) }
                        }
                    }
                }
            }
            CommandBar()
        }
    }
    LaunchedEffect(Unit) { requester.requestFocus() }
}
