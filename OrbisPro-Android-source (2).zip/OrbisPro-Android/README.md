# OrbisPro Android Frontend

Implementação Android independente do frontend do OrbisPro. O projeto WPF em `/home/ubuntu/OrbisPro` não é modificado nem convertido.

## Tecnologia

Foi escolhido **Jetpack Compose + Kotlin** porque permite reproduzir a interface baseada em estados do OrbisPro — seleção, foco, animações, navegação horizontal/vertical e adaptação a toque/teclado/controle — sem portar WPF, Windows Forms ou APIs Win32.

## Implementado

- Home horizontal com os sete aplicativos visuais originais e os mesmos dez jogos PS2 em sequência;
- GameLibrary com categoria PS2 e cards baseados no layout original;
- providers reais `Ps2GameProvider` e `WiiGameProvider`, sem lista fixa na produção;
- descoberta conservadora de NetherSX2/Dolphin apenas para informar instalação; a leitura automática de configurações privadas não é presumida;
- seleção manual de pastas via Storage Access Framework com URI persistente;
- varredura recursiva somente dentro das pastas autorizadas;
- formatos PS2 (`iso`, `chd`, `cso`, `bin`, `cue`, `gz`, `dump`) e Wii (`iso`, `wbfs`, `rvz`, `wia`, `gcz`, `ciso`);
- nomes, serial/ID quando identificável, plataforma, URI, formato e tamanho;
- `Ps2CoverService` com capas PS2 3D → fallback default → placeholder; `WiiCoverService` é uma camada separada;
- cache persistente de capas via Coil em `cacheDir/ps2-covers`;
- foco/seleção por toque, teclado e D-pad compatível com navegação Compose;
- menu de funções visual (`F2`/controle equivalente no futuro);
- background escuro azul com círculos inspirado no `bluecircles.mp4`;
- arquitetura separada: `model`, `data` e `ui`;
- `IGameProvider`, `Ps2GameProvider`, `WiiGameProvider`, `Ps2CoverService` e `WiiCoverService` independentes da UI;
- botão de iniciar apenas visual/simulado: nenhum jogo é executado e NetherSX2 não foi integrado.

## Abrir e compilar

Abra a pasta no Android Studio atualizado, aguarde o Gradle baixar as dependências e execute o módulo `app`. O ambiente desta sessão não possui Android SDK, Gradle ou ADB, portanto nenhum APK foi inventado ou declarado como compilado.

## Previews

As imagens em `docs/` são previews visuais de paridade produzidos a partir dos mesmos dados e assets. Elas não substituem a renderização Android final:

- `docs/home-preview.png`
- `docs/game-library-preview.png`

## Relação com o WPF

O frontend Android é uma implementação nova. O WPF continua sendo a aplicação Windows principal e mantém sua própria lógica, navegação e funcionalidades. Por padrão, `AppConfig.USE_DUMMY_GAMES = false`: a produção mostra somente arquivos encontrados nas URIs autorizadas. Os dummies permanecem disponíveis apenas para desenvolvimento local.

## Comportamento em dispositivo real

A abertura e o comando **Atualizar biblioteca** consultam somente as árvores SAF salvas para PS2 e Wii. Se uma permissão for revogada, o provider retorna uma lista vazia e a interface mostra o estado sem jogos; não há varredura de armazenamento privado. Arquivos são filtrados por extensão e deduplicados pelo nome base dentro da plataforma. IDs no nome do arquivo são usados quando encontrados; quando não há ID, o jogo continua listado com `ID pendente` para futura resolução de metadados.
